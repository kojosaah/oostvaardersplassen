package domain;

public abstract class Animals {


	protected int year;
	protected int predictedPopulation ;
	protected  int currentPopulation ;

	public Animals(int year) {

		this.year = year;
	}

	public int getCurrentPopulation() {
		return currentPopulation;
	}



	public int getPredictedPopulation() {
		return predictedPopulation;
	}
	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}





	public abstract int calculatePopulation();




}
