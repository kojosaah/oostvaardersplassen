package controller;

import java.net.URL;
import java.util.ResourceBundle;

import domain.PreservePopulation;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;
import main.AllPopulation;

public class GraphController implements Initializable {

	@FXML
	private LineChart<String, Number> linechart;

	@FXML
	private TextField yeartext;

	@FXML
	private Button btn;

	@FXML
	private TextField wolfNumber;

	@FXML
	private TableView<PreservePopulation> table;

	@FXML
	private TableColumn<PreservePopulation, Integer> yearCo;

	@FXML
	private TableColumn<PreservePopulation, Integer> cattleCo;

	@FXML
	private TableColumn<PreservePopulation, Integer> horseCo;

	@FXML
	private TableColumn<PreservePopulation, Integer> deerCo;

	@FXML
	private TableColumn<PreservePopulation, Integer> wolfCo;

	private ObservableList<PreservePopulation> tblData;

	private int year;

	private AllPopulation allpop;

	public void setYear(int year, int wolves) {
		this.allpop = new AllPopulation(year, wolves);
		this.drawChart();
		this.createTable();

	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		tblData = FXCollections.observableArrayList();
	}

	@FXML
	public void update() {
		this.linechart.getData().clear();
		int year;
		int wolves;
		if ((yeartext.getText() == null || yeartext.getText().length() == 0)
				|| (wolfNumber.getText() == null || wolfNumber.getText().length() == 0)) {
			Alert fail = new Alert(AlertType.INFORMATION);
			fail.setHeaderText("Error");
			fail.setContentText("Please enter a value in the field");
			fail.showAndWait();
		} else if (Integer.parseInt(yeartext.getText()) < 2018) {
			Alert fail = new Alert(AlertType.INFORMATION);
			fail.setHeaderText("Error");
			fail.setContentText("Please enter a valid year");
			fail.showAndWait();
		} else {
			year = Integer.parseInt(yeartext.getText());
			wolves = Integer.parseInt(wolfNumber.getText());
			this.allpop = null;
			this.allpop = new AllPopulation(year, wolves);
			this.drawChart();
			this.createTable();
		}

	}

	public void drawChart() {
		XYChart.Series cattlesseries = new XYChart.Series<String, Number>();
		cattlesseries.setName("Cattles");
		XYChart.Series horsesseries = new XYChart.Series<String, Number>();
		horsesseries.setName("Horses");
		XYChart.Series deersseries = new XYChart.Series<String, Number>();
		deersseries.setName("Deers");
		XYChart.Series wolvesseries = new XYChart.Series<String, Number>();
		wolvesseries.setName("Wolves");
		for (PreservePopulation prepop : this.allpop.getList()) {
			String strI = Integer.toString(prepop.getYear());
			cattlesseries.getData()
			.add(new XYChart.Data<String, Number>(strI, prepop.getCattels().getPredictedPopulation()));
			horsesseries.getData()
			.add(new XYChart.Data<String, Number>(strI, prepop.getHorses().getPredictedPopulation()));
			deersseries.getData()
			.add(new XYChart.Data<String, Number>(strI, prepop.getDeers().getPredictedPopulation()));
			wolvesseries.getData()
			.add(new XYChart.Data<String, Number>(strI, prepop.getWolves().getPredictedPopulation()));

		}
		linechart.getData().add(cattlesseries);
		linechart.getData().add(horsesseries);
		linechart.getData().add(deersseries);
		linechart.getData().add(wolvesseries);

	}

	public void createTable() {
		tblData.clear();
		yearCo.setCellValueFactory(new PropertyValueFactory<PreservePopulation, Integer>("year"));
		cattleCo.setCellValueFactory(
				new Callback<CellDataFeatures<PreservePopulation, Integer>, ObservableValue<Integer>>() {
					@Override
					public ObservableValue call(CellDataFeatures<PreservePopulation, Integer> c) {
						return new SimpleIntegerProperty(c.getValue().getCattels().getPredictedPopulation());
					}
				});
		horseCo.setCellValueFactory(
				new Callback<CellDataFeatures<PreservePopulation, Integer>, ObservableValue<Integer>>() {
					@Override
					public ObservableValue call(CellDataFeatures<PreservePopulation, Integer> c) {
						return new SimpleIntegerProperty(c.getValue().getHorses().getPredictedPopulation());
					}
				});
		deerCo.setCellValueFactory(
				new Callback<CellDataFeatures<PreservePopulation, Integer>, ObservableValue<Integer>>() {
					@Override
					public ObservableValue call(CellDataFeatures<PreservePopulation, Integer> c) {
						return new SimpleIntegerProperty(c.getValue().getDeers().getPredictedPopulation());
					}
				});
		wolfCo.setCellValueFactory(
				new Callback<CellDataFeatures<PreservePopulation, Integer>, ObservableValue<Integer>>() {
					@Override
					public ObservableValue call(CellDataFeatures<PreservePopulation, Integer> c) {
						return new SimpleIntegerProperty(c.getValue().getWolves().getPredictedPopulation());
					}
				});
		for (PreservePopulation prepop : this.allpop.getList()) {
			tblData.add(prepop);
		}
		table.setItems(tblData);
	}

}
