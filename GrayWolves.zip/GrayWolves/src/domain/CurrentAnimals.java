package domain;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class CurrentAnimals {
	private final int catlles;
	private final int horses;
	private final int deers;
	private int wolves;

	public CurrentAnimals(int wolves) {
		// super();
		this.wolves = wolves;
		List<Integer> population = new ArrayList<Integer>();
		File fileName = new File("Data.txt");
		String line = null;
		try {
			FileReader fileReader = new FileReader(fileName);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			for (int i = 0; i <= 10; i++) {
				while ((line = bufferedReader.readLine()) != null) {
					population.add(Integer.parseInt(line));
				}
			}
			bufferedReader.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
		}
		this.catlles = population.get(0);
		this.horses = population.get(1);
		this.deers = population.get(2);

	}

	public int getWolves() {
		return wolves;
	}

	public void setWolves(int wolves) {
		this.wolves = wolves;
	}

	public int getCatlles() {
		return catlles;
	}

	public int getHorses() {
		return horses;
	}

	public int getDeers() {
		return deers;
	}

}