package domain;

public class PreservePopulation {

	private Cattels cattels;
	private Horses horses;
	private Deers deers;
	private Wolves wolves;
	private int horseslast;
	private int cattleslast;
	private int deerslast;
	private int wolveslast;
	private int year;

	public PreservePopulation(int year, int cattles, int horses, int deers, int wolves) {
		this.cattleslast = cattles;
		this.horseslast = horses;
		this.deerslast = deers;
		this.wolveslast = wolves;
		this.year = year;
		this.cattels = new Cattels(this.year, this.cattleslast, this.horseslast, this.wolveslast );
		this.horses = new Horses(this.year, this.horseslast, this.cattleslast, this.wolveslast );
		this.deers = new Deers(this.year, this.deerslast, this.wolveslast );
		this.wolves = new Wolves(this.year, this.wolveslast);
	}

	public Cattels getCattelPopulation() {
		return cattels;
	}



	public int getYear() {
		return year;
	}

	public Cattels getCattels() {
		return cattels;
	}

	public void setCattels(Cattels cattels) {
		this.cattels = cattels;
	}

	public Horses getHorses() {
		return horses;
	}

	public void setHorses(Horses horses) {
		this.horses = horses;
	}

	public Deers getDeers() {
		return deers;
	}

	public void setDeers(Deers deers) {
		this.deers = deers;
	}

	public Wolves getWolves() {
		return wolves;
	}

	public void setWolves(Wolves wolves) {
		this.wolves = wolves;
	}

	public int getHorseslast() {
		return horseslast;
	}

	public void setHorseslast(int horseslast) {
		this.horseslast = horseslast;
	}

	public int getCattleslast() {
		return cattleslast;
	}

	public void setCattleslast(int cattleslast) {
		this.cattleslast = cattleslast;
	}

	public int getDeerslast() {
		return deerslast;
	}

	public void setDeerslast(int deerslast) {
		this.deerslast = deerslast;
	}

	public int getWolveslast() {
		return wolveslast;
	}

	public void setWolveslast(int wolveslast) {
		this.wolveslast = wolveslast;
	}

	public void setYear(int year) {
		this.year = year;
	}



}
