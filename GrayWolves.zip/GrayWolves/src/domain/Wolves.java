package domain;

public class Wolves extends Animals {
	private final double brpre = 0.625;
	private final double drpre = 0.45;

	public Wolves(int year) {
		super(year);
	}

	public Wolves(int year, int wolves) {
		super(year);
		this.currentPopulation = wolves;
		this.predictedPopulation = this.calculatePopulation();

	}

	@Override
	public int calculatePopulation() {
		int result;
		int diff;
		if (this.getYear() == 2017) {
			result = this.getCurrentPopulation();
		} else {
			diff = (int) (this.currentPopulation * (this.brpre - this.drpre));
			result = diff + this.currentPopulation;
		}
		return result;
	}

}
