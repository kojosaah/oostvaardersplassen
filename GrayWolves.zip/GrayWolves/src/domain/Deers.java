package domain;

public class Deers extends Animals {

	private final double rate = -0.17377;
	private final int max = 2300;
	private final double efficiency = 0.006;
	private int wolves;

	public Deers(int year) {
		super(year);
	}

	public Deers(int year, int deers, int wolves) {
		super(year);
		this.currentPopulation = deers;
		this.wolves = wolves;
		this.predictedPopulation = this.calculatePopulation();
	}

	@Override
	public int calculatePopulation() {
		int result;
		int diff;
		if (this.getYear() == 2017) {
			result = this.getCurrentPopulation();
		} else {
			diff = (int) (this.rate * this.currentPopulation * (1 - (this.currentPopulation / this.max))
					- (this.efficiency * this.currentPopulation * this.wolves));
			result = diff + this.currentPopulation;
		}

		return result;
	}

}
