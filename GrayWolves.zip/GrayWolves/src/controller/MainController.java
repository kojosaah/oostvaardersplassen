package controller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URL;
import java.util.ResourceBundle;

import domain.CurrentAnimals;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import main.AllPopulation;

public class MainController implements Initializable {

	private AllPopulation allpop;

	@FXML
	private javafx.scene.control.Button closeButton;

	private CurrentAnimals initialPopulation;

	@FXML
	private Label label;

	@FXML
	private TextField yeartext;

	@FXML
	private TextField wolfNumber;

	@FXML
	private TextField cattleNumber;

	@FXML
	private TextField horseNumber;

	@FXML
	private TextField deerNumber;

	@FXML
	private LineChart<String, Number> linechart;

	@FXML
	private Button btn;

	private Stage astage;

	@FXML
	public void calculate() throws IOException {
		int year;
		int wolves;
		if ((yeartext.getText() == null || yeartext.getText().length() == 0)
				|| (wolfNumber.getText() == null || wolfNumber.getText().length() == 0)) {
			Alert fail = new Alert(AlertType.INFORMATION);
			fail.setHeaderText("Error");
			fail.setContentText("Please enter a value in the field");
			fail.showAndWait();
		} else if (Integer.parseInt(yeartext.getText()) < 2018) {
			Alert fail = new Alert(AlertType.INFORMATION);
			fail.setHeaderText("Error");
			fail.setContentText("Please enter a valid year");
			fail.showAndWait();
		} else {
			year = Integer.parseInt(yeartext.getText());
			wolves = Integer.parseInt(wolfNumber.getText());
			FXMLLoader myLoader = new FXMLLoader(getClass().getResource("/controller/graph.fxml"));
			AnchorPane myPane = (AnchorPane) myLoader.load();
			GraphController controller = (GraphController) myLoader.getController();
			controller.setYear(year, wolves);
			Scene scene = new Scene(myPane);

			Stage dialogStage = new Stage();
			dialogStage.setTitle("OVP Graph");
			dialogStage.getIcons().add(new Image("file:resources/images/graph.png"));
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(astage);
			dialogStage.setScene(scene);

			dialogStage.showAndWait();

		}
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

	}

	public void setPrevStage(Stage astage) {
		this.astage = astage;

	}

	public void editData() {

		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(AllPopulation.class.getResource("/controller/EditData.fxml"));
			AnchorPane page = (AnchorPane) loader.load();
			Stage dialogStage = new Stage();
			dialogStage.setTitle("Edit Data");
			dialogStage.initModality(Modality.WINDOW_MODAL);
			dialogStage.initOwner(astage);
			Scene scene = new Scene(page);
			dialogStage.setScene(scene);
			dialogStage.getIcons().add(new Image("file:resources/images/edit.png"));
			MainController controller = loader.getController();
			dialogStage.showAndWait();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void handleCancel() {
		Stage stage = (Stage) closeButton.getScene().getWindow();
		stage.close();
	}

	public void handleOk() {

		initialPopulation = new CurrentAnimals(1);
		int cattle;
		int horse;
		int deer;

		if (cattleNumber.getText() == null || cattleNumber.getText().length() == 0) {
			cattle = initialPopulation.getCatlles();
		} else {
			cattle = Integer.parseInt(cattleNumber.getText());
		}

		if (horseNumber.getText() == null || horseNumber.getText().length() == 0) {
			horse = initialPopulation.getHorses();
		} else {
			horse = Integer.parseInt(horseNumber.getText());
		}

		if (deerNumber.getText() == null || deerNumber.getText().length() == 0) {
			deer = initialPopulation.getDeers();
		} else {
			deer = Integer.parseInt(deerNumber.getText());
		}

		File fileName = new File("Data.txt");
		String line = null;
		try (Writer writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Data.txt"), "utf-8"))) {
			writer.write(String.valueOf(cattle));
			writer.write("\n");
			writer.write(String.valueOf(horse));
			writer.write("\n");
			writer.write(String.valueOf(deer));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		handleCancel();
	}

	@FXML
	private void handleExit() {
		System.exit(0);
	}

	@FXML
	private void handleAbout() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("OVP Calculator");
		((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
		.add(new Image("file:resources/images/about.png"));
		alert.setHeaderText("About");
		alert.setContentText("Author: Abel Sebhatu, Lucas ten Boom, Abdelhamid Lafkiri& "
				+ "Stephen Ransford Saah \nWebsite: http://inholland.nl");
		alert.showAndWait();
	}

	@FXML
	private void handleCalculatorHelp() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("OVP Calculator");
		((Stage) alert.getDialogPane().getScene().getWindow()).getIcons()
		.add(new Image("file:resources/images/help.png"));
		alert.setHeaderText("Help");
		alert.setContentText("Welcome the Oostvaardersplassen (OVP) Calculator.\n"
				+ "This application helps in predicting the population growth and sizes for the three large herbivores: "
				+ "Cattle, Horses and Deer. This also includes wolves as they are the predator inputs to check the growth "
				+ "of the large herbivores. "
				+ "\nTo use this application, please insert a required number of wolves and time (in years). "
				+ "Here years are defined higher than 2017. Click CALCULATE to access a visual output of results."
				+ " \nAdditional tuning to underlying population sizes of the large herbivores can be accessed under Edit -> Configurations."
				+ " The user can Edit the data for Cattle, Horses and Deer.");
		alert.showAndWait();
	}

}
