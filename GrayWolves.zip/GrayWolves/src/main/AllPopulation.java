package main;

import java.io.IOException;
import java.util.ArrayList;

import controller.MainController;
import domain.CurrentAnimals;
import domain.PreservePopulation;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AllPopulation extends Application {

	private ArrayList<PreservePopulation> list;
	private int year;
	private Stage primaryStage;
	private AnchorPane rootLayout;
	private CurrentAnimals currentAnimals;

	public static void main(String[] args) {
		launch(args);
	}

	public AllPopulation(int year, int wolfNummer) {
		this.year = year;
		this.list = new ArrayList<PreservePopulation>();
		this.currentAnimals = new CurrentAnimals(wolfNummer);
		for (int i = 2017; i <= this.year; i++) {
			int cattles;
			int horses;
			int deers;
			int wolves;
			if (list.size() == 0) {
				cattles = this.currentAnimals.getCatlles();
				horses = this.currentAnimals.getHorses();
				deers = this.currentAnimals.getDeers();
				wolves = this.currentAnimals.getWolves();
				PreservePopulation apreservePop = new PreservePopulation(i, cattles, horses, deers, wolves);
				list.add(apreservePop);
			} else {

				PreservePopulation preserve = list.get(list.size() - 1);
				cattles = preserve.getCattels().getPredictedPopulation();
				horses = preserve.getHorses().getPredictedPopulation();
				deers = preserve.getDeers().getPredictedPopulation();
				wolves = preserve.getWolves().getPredictedPopulation();
				PreservePopulation apreservePop = new PreservePopulation(i, cattles, horses, deers, wolves);
				list.add(apreservePop);
			}
		}
	}

	public AllPopulation() {

	}

	public ArrayList<PreservePopulation> getList() {
		return list;
	}

	public void setList(ArrayList<PreservePopulation> list) {
		this.list = list;
	}

	public void eachprePop() {
		for (PreservePopulation apre : list) {

			System.out.println(apre.getCattelPopulation().getPredictedPopulation());
		}
	}

	@Override

	public void start(Stage priStage) throws Exception {

		this.primaryStage = priStage;
		this.primaryStage.setTitle("OVP Calculator");
		this.primaryStage.getIcons().add(new Image("file:resources/images/wolf.png"));
		FXMLLoader myLoader = new FXMLLoader(getClass().getResource("/controller/HomePage.fxml"));
		BorderPane myPane = (BorderPane) myLoader.load();
		MainController controller = (MainController) myLoader.getController();
		controller.setPrevStage(primaryStage);
		Scene myScene = new Scene(myPane);
		primaryStage.setScene(myScene);
		primaryStage.show();
	}

	public void initRootLayout() {
		try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(AllPopulation.class.getResource("/controller/graph.fxml"));
			rootLayout = (AnchorPane) loader.load();
			MainController controller = loader.getController();
			Scene scene = new Scene(rootLayout);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
