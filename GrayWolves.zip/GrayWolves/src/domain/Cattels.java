
package domain;

public class Cattels extends Animals {
	private final double rate = -0.178;
	private final double alfa = 1.5;
	private final double beta = 0.5;
	private final double efficiency = 0.015;
	private final int max = 500;
	private int horses;
	private int wolves;

	public Cattels(int year) {
		super(year);
		this.predictedPopulation = this.calculatePopulation();
	}

	public Cattels(int year, int currentpopulation, int horse, int wolf) {
		super(year);
		this.currentPopulation = currentpopulation;
		this.horses = horse;
		this.wolves = wolf;
		this.predictedPopulation = this.calculatePopulation();
	}

	@Override
	public int calculatePopulation() {
		int diff;
		int result;
		if (this.getYear() == 2017) {
			result = this.getCurrentPopulation();
		} else {

			diff = (int) (this.rate * this.currentPopulation
					* ((this.max - this.currentPopulation - (this.alfa * this.horses)) / this.max)
					- (this.efficiency * this.currentPopulation * this.wolves));
			result = this.currentPopulation + diff;
		}
		return result;
		/*
		 * double b = (-1*this.rate)*this.year; double a = Math.E; double result
		 * = this.max/(1+((((this.max -
		 * this.currentPopulation)/this.currentPopulation))*Math.pow(a, b)));
		 * return result;
		 */
	}

}
