package domain;

public class Horses extends Animals {
	private final double rate = -0.09;
	private final double beta = 0.5;
	private final int max = 1000;
	private final double efficiency = 0.005;
	private int cattles;
	private int wolves;

	public Horses(int year) {
		super(year);
		this.predictedPopulation = this.calculatePopulation();
	}

	public Horses(int year, int currentpopulation, int cattles, int wolf) {
		super(year);
		this.currentPopulation = currentpopulation;
		this.cattles = cattles;
		this.wolves = wolf;
		this.predictedPopulation = this.calculatePopulation();
	}

	@Override
	public int calculatePopulation() {
		int diff;
		int result;
		if (this.getYear() == 2017) {
			result = this.getCurrentPopulation();
		} else {
			diff = (int) (this.rate * this.currentPopulation
					* ((this.max - this.currentPopulation - (this.beta * this.cattles)) / this.max)
					- (this.efficiency * this.currentPopulation * this.wolves));
			result = diff + this.currentPopulation;
		}

		return result;
	}

}
